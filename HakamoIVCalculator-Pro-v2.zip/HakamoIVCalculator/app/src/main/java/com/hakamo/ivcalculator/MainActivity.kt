package com.hakamo.ivcalculator

import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private var night = true
    private lateinit var root: LinearLayout
    private lateinit var card: LinearLayout
    private lateinit var resultCard: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var subtitle: TextView
    private lateinit var modeButton: TextView
    private lateinit var volume: EditText
    private lateinit var hours: EditText
    private lateinit var minutes: EditText
    private lateinit var drop: Spinner

    private val nightBg = Color.rgb(4, 6, 12)
    private val darkBg = Color.rgb(9, 15, 27)
    private val cardNight = Color.rgb(12, 17, 29)
    private val cardDark = Color.rgb(18, 28, 45)
    private val white = Color.rgb(244, 248, 252)
    private val muted = Color.rgb(154, 170, 190)
    private val accent = Color.rgb(67, 230, 197)
    private val blue = Color.rgb(93, 153, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        applyMode()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun rounded(color: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            stroke?.let { setStroke(dp(1), it) }
        }

    private fun label(text: String, size: Float = 13f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            setPadding(dp(2), dp(2), dp(2), dp(7))
        }

    private fun field(hint: String): EditText =
        EditText(this).apply {
            this.hint = hint
            textSize = 17f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(16), 0, dp(16), 0)
            setTextColor(white)
            setHintTextColor(muted)
            background = rounded(cardNight, 16, Color.rgb(38, 53, 74))
            layoutParams = LinearLayout.LayoutParams(-1, dp(56))
        }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(22))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        brand.addView(TextView(this).apply {
            text = "HAKAMO"
            textSize = 13f
            setTextColor(accent)
            letterSpacing = .18f
        })
        brand.addView(TextView(this).apply {
            text = "IV Calculator"
            textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(white)
        })
        subtitle = TextView(this).apply { text = "حساب معدل المحاليل • سريع ودقيق"; textSize = 12f; setTextColor(muted) }
        brand.addView(subtitle)
        header.addView(brand)

        modeButton = TextView(this).apply {
            text = "☾  NIGHT"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(Color.rgb(24, 31, 47), 16, Color.rgb(52, 69, 94))
            setPadding(dp(13), 0, dp(13), 0)
            setOnClickListener { night = !night; applyMode() }
        }
        header.addView(modeButton, LinearLayout.LayoutParams(dp(100), dp(42)))
        root.addView(header)

        // Hero card
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.rgb(12, 34, 43), 24, Color.rgb(42, 130, 121))
        }
        hero.addView(TextView(this).apply {
            text = "💧"
            textSize = 34f
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = "احسب الـ Rate في ثواني"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(white)
            gravity = Gravity.CENTER
        })
        hero.addView(TextView(this).apply {
            text = "أدخل الكمية والمدة، والتطبيق يحسب mL/hr تلقائيًا"
            textSize = 12f
            setTextColor(Color.rgb(187, 214, 218))
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
        })
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(cardNight, 24, Color.rgb(35, 49, 70))
        }

        card.addView(label("بيانات المحلول"))
        volume = field("كمية المحلول  •  mL   مثال: 500")
        hours = field("المدة  •  ساعات   مثال: 2")
        minutes = field("دقائق إضافية   مثال: 30")
        card.addView(label("الكمية", 12f)); card.addView(volume)
        card.addView(label("المدة", 12f).apply { setPadding(dp(2), dp(14), dp(2), dp(7)) }); card.addView(hours)
        card.addView(minutes, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(9) })

        card.addView(label("نوع الـ IV set", 12f).apply { setPadding(dp(2), dp(14), dp(2), dp(7)) })
        drop = Spinner(this)
        val options = arrayOf("بدون حساب القطرات", "10 gtt/mL", "15 gtt/mL", "20 gtt/mL", "60 gtt/mL • Microdrip")
        drop.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        card.addView(drop, LinearLayout.LayoutParams(-1, dp(52)))

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, 0) }
        val calc = TextView(this).apply {
            text = "احسب المعدل  →"
            textSize = 16f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(4, 18, 20))
            background = rounded(accent, 17)
            setOnClickListener { calculate() }
        }
        val clear = TextView(this).apply {
            text = "مسح"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(Color.rgb(25, 33, 48), 17, Color.rgb(53, 67, 89))
            setOnClickListener { clearAll() }
        }
        buttons.addView(calc, LinearLayout.LayoutParams(0, dp(56), 1f))
        buttons.addView(clear, LinearLayout.LayoutParams(dp(90), dp(56)).apply { marginStart = dp(9) })
        card.addView(buttons)
        root.addView(card)

        resultCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(Color.rgb(10, 40, 44), 24, Color.rgb(67, 230, 197))
            visibility = View.GONE
        }
        resultText = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(white)
            setLineSpacing(0f, 1.25f)
        }
        resultCard.addView(resultText)
        root.addView(resultCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val note = TextView(this).apply {
            text = "⚠  أداة حسابية فقط • راجع وصف الطبيب وبروتوكول المنشأة ونوع الـ IV set قبل الإعطاء."
            textSize = 11f
            setTextColor(Color.rgb(174, 186, 202))
            setPadding(dp(12), dp(13), dp(12), dp(13))
            background = rounded(Color.rgb(14, 20, 31), 15, Color.rgb(40, 50, 67))
        }
        root.addView(note, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        root.addView(TextView(this).apply {
            text = "Under the supervision of  HAKAMO"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(0, dp(18), 0, 0)
        })

        setContentView(scroll)
        animateHero(hero)
    }

    private fun calculate() {
        val v = volume.text.toString().toDoubleOrNull()
        val h = hours.text.toString().toDoubleOrNull() ?: 0.0
        val m = minutes.text.toString().toDoubleOrNull() ?: 0.0
        if (v == null || v <= 0 || (h <= 0 && m <= 0) || m > 59) {
            Toast.makeText(this, "أدخل كمية ومدة صحيحة (والدقائق من 0 إلى 59)", Toast.LENGTH_SHORT).show()
            return
        }
        val totalHours = h + m / 60.0
        val rate = v / totalHours
        val factor = when (drop.selectedItemPosition) { 1 -> 10; 2 -> 15; 3 -> 20; 4 -> 60; else -> 0 }
        val out = StringBuilder("المعدل المطلوب\n\n")
        out.append(format(rate)).append("  mL/hr")
        if (factor > 0) {
            val gtt = (v * factor) / (totalHours * 60.0)
            out.append("\n\nمعدل التنقيط التقريبي\n").append(gtt.roundToInt()).append("  gtt/min")
        }
        resultText.text = out.toString()
        resultCard.visibility = View.VISIBLE
        resultCard.alpha = 0f
        resultCard.translationY = dp(10).toFloat()
        resultCard.animate().alpha(1f).translationY(0f).setDuration(350).setInterpolator(AccelerateDecelerateInterpolator()).start()
    }

    private fun clearAll() {
        volume.text.clear(); hours.text.clear(); minutes.text.clear(); drop.setSelection(0)
        resultCard.visibility = View.GONE
    }

    private fun format(x: Double) = if (x % 1.0 == 0.0) x.toInt().toString() else String.format("%.1f", x)

    private fun applyMode() {
        root.setBackgroundColor(if (night) nightBg else darkBg)
        card.background = rounded(if (night) cardNight else cardDark, 24, Color.rgb(35, 49, 70))
        volume.background = rounded(if (night) cardNight else Color.rgb(10, 19, 32), 16, Color.rgb(38, 53, 74))
        hours.background = rounded(if (night) cardNight else Color.rgb(10, 19, 32), 16, Color.rgb(38, 53, 74))
        minutes.background = rounded(if (night) cardNight else Color.rgb(10, 19, 32), 16, Color.rgb(38, 53, 74))
        modeButton.text = if (night) "☾  NIGHT" else "◐  DARK"
    }

    private fun animateHero(v: View) {
        val animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            repeatCount = 1
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { v.alpha = 0.92f + (it.animatedValue as Float) * 0.08f }
        }
        animator.start()
    }
}
