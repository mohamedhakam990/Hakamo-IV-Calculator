package com.hakamo.ivcalculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.view.ViewGroup
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(7,17,31)
    private val card = Color.rgb(16,28,45)
    private val accent = Color.rgb(53,208,186)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 28)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(content)

        fun tv(text: String, size: Float, color: Int = Color.WHITE): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(8, 8, 8, 8)
            }

        content.addView(tv("💧", 34f))
        content.addView(tv("Hakamo IV Calculator", 26f))
        content.addView(tv("حاسبة معدل المحاليل", 15f, Color.LTGRAY))

        val volume = EditText(this).apply {
            hint = "كمية المحلول (mL) — مثال 500"
            inputType = 2 or 8192
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val hours = EditText(this).apply {
            hint = "الساعات — مثال 2"
            inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val minutes = EditText(this).apply {
            hint = "الدقائق — مثال 30"
            inputType = 2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        val drop = Spinner(this)
        val options = arrayOf("بدون حساب القطرات", "10 gtt/mL", "15 gtt/mL", "20 gtt/mL", "60 gtt/mL (Microdrip)")
        drop.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)

        listOf(volume, hours, minutes).forEach {
            it.setBackgroundColor(card)
            content.addView(it, ViewGroup.LayoutParams(-1, 58))
            (it.layoutParams as LinearLayout.LayoutParams).setMargins(0, 12, 0, 0)
        }
        content.addView(drop, ViewGroup.LayoutParams(-1, 58))

        val result = tv("", 18f)
        result.setPadding(18, 24, 18, 24)
        result.setBackgroundColor(Color.rgb(20,60,74))
        content.addView(result, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        result.visibility = TextView.GONE

        val calc = Button(this).apply { text = "احسب المعدل"; setTextColor(Color.BLACK); setBackgroundColor(accent) }
        val clear = Button(this).apply { text = "مسح" }
        content.addView(calc, ViewGroup.LayoutParams(-1, 58))
        content.addView(clear, ViewGroup.LayoutParams(-1, 58))

        val note = tv("⚠️ الأداة للحساب فقط. راجع وصف الطبيب وبروتوكول المنشأة ونوع الـ IV set قبل إعطاء المحلول.", 12f, Color.LTGRAY)
        content.addView(note)
        content.addView(tv("Under the supervision of Hakamo", 12f, Color.GRAY))

        calc.setOnClickListener {
            val v = volume.text.toString().toDoubleOrNull()
            val h = hours.text.toString().toDoubleOrNull() ?: 0.0
            val m = minutes.text.toString().toDoubleOrNull() ?: 0.0
            if (v == null || v <= 0 || (h <= 0 && m <= 0)) {
                Toast.makeText(this, "أدخل كمية ومدة صحيحة", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val total = h + m / 60.0
            val rate = v / total
            val factor = when (drop.selectedItemPosition) { 1 -> 10; 2 -> 15; 3 -> 20; 4 -> 60; else -> 0 }
            val text = StringBuilder("المعدل المطلوب\n${format(rate)} mL/hr")
            if (factor > 0) text.append("\n\nمعدل التنقيط التقريبي\n${(v * factor / (total * 60)).roundToInt()} gtt/min")
            result.text = text.toString()
            result.visibility = TextView.VISIBLE
        }
        clear.setOnClickListener {
            volume.text.clear(); hours.text.clear(); minutes.text.clear()
            drop.setSelection(0); result.visibility = TextView.GONE
        }

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun format(x: Double): String =
        if (x % 1.0 == 0.0) x.toInt().toString() else String.format("%.1f", x)
}
