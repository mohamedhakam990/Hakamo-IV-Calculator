# Hakamo Nursing Assistant V8

Android starter project for Hakamo Nursing Assistant V8.

## Build on GitHub
1. Upload the **contents** of this folder to a new GitHub repository.
2. Open **Actions**.
3. Run **Build Hakamo Nursing APK**.
4. When it finishes, open the workflow run and download the artifact:
   `Hakamo-Nursing-Assistant-V8-debug`

This workflow intentionally does not require `gradlew`; GitHub Actions installs Gradle 8.9 directly.

## App
- Package: `com.hakamo.nursingassistant`
- Version: `8.0` / code `8`
- minSdk: 24
- targetSdk: 35
- compileSdk: 35

## Medical safety
The app is an educational nursing reference. Drug doses, infusions, emergency protocols, and calculations must be checked against the responsible clinician and current institutional protocols before clinical use.
