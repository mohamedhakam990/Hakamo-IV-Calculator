# Hakamo Nursing Assistant V8 - ProGuard rules
