plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hakamo.nursingassistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hakamo.nursingassistant"
        minSdk = 24
        targetSdk = 35
        versionCode = 8
        versionName = "8.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}


dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}
