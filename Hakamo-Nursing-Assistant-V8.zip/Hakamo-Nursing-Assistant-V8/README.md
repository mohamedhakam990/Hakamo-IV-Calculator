# Hakamo Nursing Assistant V8

Starter Android project for a professional nursing assistant app.

## Included
- Arabic RTL-ready UI
- Dark medical theme
- Nursing / ICU sections
- IV Calculator entry point
- Drugs / Labs / Procedures / Care Plan / Handover entry points
- GitHub Actions APK build

## Build
Use Android Studio with JDK 17, or GitHub Actions via **Actions → Build Hakamo Nursing Assistant V8 → Run workflow**.

## Package
`com.hakamo.nursingassistant`

## Version
8.0 (versionCode 8)

> Educational reference only. Clinical decisions must follow authorized medical guidance and local hospital protocols.
