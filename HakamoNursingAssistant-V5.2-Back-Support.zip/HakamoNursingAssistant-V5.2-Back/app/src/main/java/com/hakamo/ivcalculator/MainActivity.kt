package com.hakamo.ivcalculator

import android.content.Intent
import android.net.Uri
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import kotlin.math.*

class MainActivity: AppCompatActivity(){
 private lateinit var body:LinearLayout; private var mode=0; private var page="home"; private var parentPage="home"
 private val accent=Color.rgb(70,226,194); private val blue=Color.rgb(103,156,255)
 private fun dark()=(resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES
 private fun bg()=if(dark())Color.rgb(5,8,14) else Color.rgb(246,248,252)
 private fun card()=if(dark())Color.rgb(14,20,31) else Color.WHITE
 private fun fg()=if(dark())Color.rgb(244,247,251) else Color.rgb(25,31,42)
 private fun muted()=if(dark())Color.rgb(158,171,191) else Color.rgb(101,113,130)
 private fun dp(n:Int)= (n*resources.displayMetrics.density).roundToInt()
 private fun glass(c:Int=card(),s:Int=if(dark())Color.rgb(43,56,76) else Color.rgb(218,225,236),r:Int=22)=GradientDrawable().apply{setColor(if(dark())Color.argb(205,Color.red(c),Color.green(c),Color.blue(c)) else Color.argb(225,Color.red(c),Color.green(c),Color.blue(c)));cornerRadius=dp(r).toFloat();setStroke(dp(1),s)}
 private fun tv(s:String,z:Float,col:Int=fg(),bold:Boolean=false)=TextView(this).apply{text=s;textSize=z;setTextColor(col);if(bold)setTypeface(typeface,1)}
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  mode=getPreferences(0).getInt("mode",0)
  applyMode()
  shell()
  onBackPressedDispatcher.addCallback(this, object: OnBackPressedCallback(true){
    override fun handleOnBackPressed(){
      if(page=="home"){ finish() } else {
        when(parentPage){
          "calculators"->calculators()
          "medicines"->medicines()
          "assessment"->assessment()
          "reference"->reference()
          else->home()
        }
      }
    }
  })
  home()
}
 private fun applyMode(){AppCompatDelegate.setDefaultNightMode(when(mode){1->AppCompatDelegate.MODE_NIGHT_NO;2->AppCompatDelegate.MODE_NIGHT_YES;else->AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM})}
 private fun shell(){val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg())};val h=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(16),dp(18),dp(10))};val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutParams=LinearLayout.LayoutParams(0,-2,1f)};b.addView(tv("HAKAMO",12f,accent,true));b.addView(tv("Nursing Assistant\nمساعد التمريض",25f,fg(),true));b.addView(tv("Pocket tools • Offline",11f,muted()));h.addView(b);val m=tv(themeName(),12f);m.gravity=Gravity.CENTER;m.background=glass(if(dark())Color.rgb(23,30,44) else Color.rgb(238,242,248),if(dark())Color.rgb(58,72,94) else Color.rgb(211,219,231),16);m.setPadding(dp(10),0,dp(10),0);m.setOnClickListener{mode=(mode+1)%3;getPreferences(0).edit().putInt("mode",mode).apply();recreate()};h.addView(m,LinearLayout.LayoutParams(dp(106),dp(44)));root.addView(h);body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),0,dp(18),dp(24))};val scroll=ScrollView(this).apply{isFillViewport=true;addView(body)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(8),dp(8),dp(10));setBackgroundColor(if(dark())Color.rgb(9,13,21) else Color.WHITE)};arrayOf("⌂","🧮","💊","🩺","📚").forEachIndexed{i,x->val n=tv(x,22f,if(i==0)accent else muted());n.gravity=Gravity.CENTER;n.setOnClickListener{when(i){0->home();1->calculators();2->medicines();3->assessment();4->reference()}};nav.addView(n,LinearLayout.LayoutParams(0,dp(52),1f))};root.addView(nav);setContentView(root)}
 private fun themeName()=when(mode){0->"◐ SYSTEM";1->"☀ DAY";else->"☾ NIGHT"}
 private fun clear(title:String,sub:String){
  body.removeAllViews()
  if(page!="home"){
    val back=tv("‹  رجوع  •  Back",14f,accent,true)
    back.gravity=Gravity.CENTER
    back.background=glass(if(dark())Color.rgb(13,29,36) else Color.rgb(237,250,247),accent,15)
    back.setPadding(dp(12),0,dp(12),0)
    back.setOnClickListener{
      when(parentPage){
        "calculators"->calculators()
        "medicines"->medicines()
        "assessment"->assessment()
        "reference"->reference()
        else->home()
      }
    }
    body.addView(back,LinearLayout.LayoutParams(-1,dp(48)).apply{bottomMargin=dp(12)})
  }
  body.addView(tv(title,27f,fg(),true))
  body.addView(tv(sub,12f,muted()).apply{setPadding(0,dp(4),0,dp(14))})
}
 private fun menu(icon:String,name:String,desc:String,go:()->Unit){val c=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=glass();setOnClickListener{go()}};c.addView(tv(icon,27f),LinearLayout.LayoutParams(dp(52),dp(58)));val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutParams=LinearLayout.LayoutParams(0,-2,1f)};col.addView(tv(name,16f,fg(),true));col.addView(tv(desc,11f,muted()));c.addView(col);c.addView(tv("›",28f,muted()));body.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})}
 private fun home(){page="home";parentPage="home";
  clear("مساعد Hakamo للتمريض","Hakamo Nursing Assistant • بسيط، سريع، عربي أولًا")
  val hero=LinearLayout(this).apply{
    orientation=LinearLayout.VERTICAL
    setPadding(dp(18),dp(18),dp(18),dp(18))
    background=glass(if(dark())Color.argb(190,9,38,42) else Color.argb(220,235,250,247),Color.rgb(66,174,158),24)
  }
  hero.addView(tv("💧 HAKAMO",13f,accent,true))
  hero.addView(tv("كل أدوات التمريض في مكان واحد",22f,fg(),true))
  hero.addView(tv("حسابات • تقييم • أدوية • مراجع\nCalculators • Assessment • Medicines • References",12f,muted()))
  body.addView(hero,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(14)})
  menu("🧮","الحاسبات • Calculators","معدل المحلول • الجرعات • التخفيف • الوحدات"){calculators()}
  menu("💊","دليل الأدوية • Medicines","اسم الدواء • الاستخدامات • التحذيرات • الآثار الجانبية"){medicines()}
  menu("🩺","التقييم • Assessment","GCS • NEWS2 • BMI • BSA • I&O • إخراج البول"){assessment()}
  menu("📚","المراجع • References","العلامات الحيوية • التحاليل • الاختصارات • السلامة"){reference()}
  menu("📲","تواصل مع Hakamo","Telegram • TikTok • Facebook • YouTube"){contact()}
  val n=tv("⚠ مهم: المعلومات التعليمية لا تستبدل وصف الطبيب أو الصيدلي أو بروتوكول المنشأة. لا تعتمد على التطبيق وحده لاتخاذ قرار علاجي.",11f,muted())
  n.setPadding(dp(12),dp(14),dp(12),dp(14))
  n.background=glass(if(dark())Color.argb(180,25,22,17) else Color.argb(220,255,249,236),if(dark())Color.rgb(82,70,49) else Color.rgb(235,207,150),16)
  body.addView(n)
}
 private fun calculators(){page="calculators";parentPage="home";clear("🧮 Calculators","حسابات سريعة وواضحة");menu("💧","IV Rate\nمعدل المحلول","mL/hr + gtt/min + time"){iv()};menu("💊","Dose","جرعة مطلوبة من تركيز متاح"){dose()};menu("🧪","Dilution\nالتخفيف","C1V1 = C2V2\nمعادلة التخفيف"){dilute()};menu("⚖","Weight-based\nحسب الوزن","mg/kg or mcg/kg • Calculation only\nحساب رياضي فقط"){weight()};menu("🔁","Units","mg • g • mcg • mL • L • kg"){units()}}
 private fun inp(h:String)=EditText(this).apply{hint=h;textSize=16f;setSingleLine();setTextColor(fg());setHintTextColor(muted());setPadding(dp(14),0,dp(14),0);background=glass(if(dark())Color.rgb(9,14,23) else Color.rgb(250,252,255),if(dark())Color.rgb(43,57,77) else Color.rgb(214,222,233),15)}
 private fun btn(s:String,go:()->Unit)=tv(s,15f,Color.rgb(3,20,19),true).apply{gravity=Gravity.CENTER;background=glass(accent,accent,16);setOnClickListener{go()};setPadding(dp(8),0,dp(8),0)}
 private fun out(s:String){val r=tv(s,18f,fg(),true);r.gravity=Gravity.CENTER;r.setPadding(dp(14),dp(18),dp(14),dp(18));r.background=glass(if(dark())Color.rgb(8,39,42) else Color.rgb(236,251,247),Color.rgb(63,181,164),20);body.addView(r,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(14)});r.alpha=0f;r.animate().alpha(1f).setDuration(350).start()}
 private fun add(v:android.view.View){body.addView(v,LinearLayout.LayoutParams(-1,dp(56)).apply{bottomMargin=dp(9)})}
 private fun num(e:EditText)=e.text.toString().toDoubleOrNull() ?: -1.0
 private fun fmt(x:Double)=if(x.isFinite()&&abs(x-round(x))<1e-8)round(x).toInt().toString() else String.format("%.2f",x)
 private fun iv(){page="iv";parentPage="calculators";clear("💧 IV Rate","mL/hr • gtt/min • زمن الانتهاء");val v=inp("Volume mL");val h=inp("Hours");val m=inp("Minutes");add(v);add(h);add(m);val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("بدون قطرات","10 gtt/mL","15 gtt/mL","20 gtt/mL","60 gtt/mL"));body.addView(sp,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(10)});body.addView(btn("Calculate\nاحسب"){val a=num(v);val t=num(h)+num(m)/60;if(a>0&&t>0){var s="Rate = ${fmt(a/t)} mL/hr";val f=when(sp.selectedItemPosition){1->10;2->15;3->20;4->60;else->0};if(f>0)s+="\n\nDrops = ${round(a*f/(t*60)).toInt()} gtt/min";s+="\n\nDuration = ${fmt(t)} hr";out(s)}else toast("أدخل القيم الصحيحة")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun dose(){page="dose";parentPage="calculators";clear("💊 Dose Calculator","حساب رياضي فقط");val d=inp("Desired dose mg");val a=inp("Available dose mg");val v=inp("Available volume mL");add(d);add(a);add(v);body.addView(btn("Calculate\nاحسب"){val x=num(d);val y=num(a);val z=num(v);if(x>0&&y>0&&z>0)out("Volume = ${fmt(x/y*z)} mL")else toast("أدخل القيم")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun dilute(){page="dilute";parentPage="calculators";clear("🧪 Dilution","C1 × V1 = C2 × V2");val c1=inp("C1 original");val c2=inp("C2 desired");val v2=inp("V2 final mL");add(c1);add(c2);add(v2);body.addView(btn("Calculate V1\nاحسب V1"){val a=num(c1);val b=num(c2);val c=num(v2);if(a>0&&b>0&&c>0)out("V1 = ${fmt(b*c/a)} mL")else toast("أدخل القيم")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun weight(){page="weight";parentPage="calculators";clear("⚖ Weight-based","mg/kg or mcg/kg • Calculation only\nحساب رياضي فقط");val d=inp("Dose per kg");val w=inp("Weight kg");add(d);add(w);body.addView(btn("Calculate\nاحسب"){val a=num(d);val b=num(w);if(a>0&&b>0)out("Calculated dose = ${fmt(a*b)}")else toast("أدخل القيم")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun units(){page="units";parentPage="calculators";clear("🔁 Unit Converter","تحويلات شائعة");val x=inp("Value");val sp=Spinner(this);sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("mg → mcg","g → mg","mcg → mg","L → mL","mL → L","kg → g","g → kg"));add(x);body.addView(sp,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(10)});body.addView(btn("Convert\nحوّل"){val a=num(x);if(a>=0){val y=when(sp.selectedItemPosition){0->a*1000;1->a*1000;2->a/1000;3->a*1000;4->a/1000;5->a*1000;else->a/1000};out(fmt(y))}},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun assessment(){page="assessment";parentPage="home";clear("🩺 Assessment","تقييم ومتابعة");menu("🧠","GCS\nمقياس غلاسكو","Eyes • Verbal • Motor\nالعين • الكلام • الحركة"){gcs()};menu("📈","NEWS2\nالتقييم المبكر","RR • SpO₂ • BP • Pulse • Temp"){news()};menu("⚖","BMI / BSA\nمؤشر كتلة الجسم • مساحة سطح الجسم","Body measurements"){bmi()};menu("💧","Intake & Output\nالداخل والخارج","Balance mL"){io()};menu("🚽","Urine Output\nإخراج البول","mL/kg/hr\nمل/كجم/ساعة"){urine()}}
 private fun gcs(){page="gcs";parentPage="assessment";clear("🧠 GCS","اختر أفضل استجابة مُلاحظة");val e=Spinner(this);val v=Spinner(this);val m=Spinner(this);e.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("E4 Spontaneous","E3 Sound","E2 Pressure","E1 None"));v.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("V5 Orientated","V4 Confused","V3 Words","V2 Sounds","V1 None"));m.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("M6 Obeys","M5 Localising","M4 Normal flexion","M3 Abnormal flexion","M2 Extension","M1 None"));listOf(e,v,m).forEach{body.addView(it,LinearLayout.LayoutParams(-1,dp(56)).apply{bottomMargin=dp(9)})};body.addView(btn("Calculate GCS\nاحسب GCS"){val es=4-e.selectedItemPosition;val vs=5-v.selectedItemPosition;val ms=6-m.selectedItemPosition;out("GCS = ${es+vs+ms}\nE${es} V${vs} M${ms}")},LinearLayout.LayoutParams(-1,dp(54)));body.addView(tv("توثيق E/V/M منفصلًا أفضل من الاعتماد على المجموع وحده.",11f,muted()).apply{setPadding(0,dp(12),0,0)})}
 private fun news(){page="news";parentPage="assessment";clear("📈 NEWS2","حساب الدرجة — راجع البروتوكول المحلي");val rr=inp("RR /min");val sp=inp("SpO₂ %");val bp=inp("SBP mmHg");val pu=inp("Pulse /min");val te=inp("Temp °C");listOf(rr,sp,bp,pu,te).forEach{add(it)};val o=Spinner(this);o.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Room air","Supplemental O₂"));val c=Spinner(this);c.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("Alert","CVPU / altered"));body.addView(o,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(8)});body.addView(c,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(10)});body.addView(btn("Calculate NEWS2\nاحسب NEWS2"){val a=num(rr);val b=num(sp);val d=num(bp);val p=num(pu);val t=num(te);if(a>0&&b>0&&d>0&&p>0&&t>0){val s=rs(a)+ss(b)+bs(d)+ps(p)+ts(t)+(if(o.selectedItemPosition==1)2 else 0)+(if(c.selectedItemPosition==1)3 else 0);out("NEWS2 = $s\nراجع الإجراء المناسب حسب سياسة المنشأة.")}else toast("أدخل العلامات الحيوية")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun rs(x:Double)=when{ x<=8->3;x<=11->1;x<=20->0;x<=24->2;else->3};private fun ss(x:Double)=when{x>=96->0;x>=94->1;x>=92->2;else->3};private fun bs(x:Double)=when{x<=90->3;x<=100->2;x<=110->1;x<=219->0;else->3};private fun ps(x:Double)=when{x<=40->3;x<=50->1;x<=90->0;x<=110->1;x<=130->2;else->3};private fun ts(x:Double)=when{x<=35->3;x<=36->1;x<=38->0;x<=39->1;else->2}
 private fun bmi(){page="bmi";parentPage="assessment";clear("⚖ BMI / BSA","حسابات جسمية");val w=inp("Weight kg");val h=inp("Height cm");add(w);add(h);body.addView(btn("Calculate\nاحسب"){val a=num(w);val b=num(h);if(a>0&&b>0)out("BMI = ${fmt(a/(b/100).pow(2))}\nBSA ≈ ${fmt(sqrt(a*b/3600))} m²")else toast("أدخل الوزن والطول")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun io(){page="io";parentPage="assessment";clear("💧 Intake & Output","حساب الميزان");val i=inp("Intake mL");val o=inp("Output mL");add(i);add(o);body.addView(btn("Calculate\nاحسب"){val a=num(i);val b=num(o);if(a>=0&&b>=0)out("Balance = ${fmt(a-b)} mL")else toast("أدخل القيم")},LinearLayout.LayoutParams(-1,dp(54)))}
 private fun urine(){page="urine";parentPage="assessment";clear("🚽 Urine Output","mL/kg/hr\nمل/كجم/ساعة");val v=inp("Urine mL");val h=inp("Hours");val w=inp("Weight kg");listOf(v,h,w).forEach{add(it)};body.addView(btn("Calculate\nاحسب"){val a=num(v);val b=num(h);val c=num(w);if(a>=0&&b>0&&c>0)out("${fmt(a/(b*c))} mL/kg/hr")else toast("أدخل القيم")},LinearLayout.LayoutParams(-1,dp(54)))}

 private data class Drug(val generic:String,val ar:String,val category:String,val uses:String,val warnings:String,val effects:String)

 private val drugs=listOf(
  Drug("Paracetamol / Acetaminophen","باراسيتامول / أسيتامينوفين","Pain & Fever\nمسكن وخافض حرارة","تخفيف الألم والحمى.","الحذر مع أمراض الكبد ومع المنتجات الأخرى التي تحتوي على نفس المادة.","غثيان، طفح، ونادرًا أذى كبدي خاصة مع الجرعات الزائدة."),
  Drug("Ibuprofen","إيبوبروفين","NSAID\nمضاد التهاب غير ستيرويدي","الألم والالتهاب والحمى في حالات مناسبة.","الحذر مع قرحة/نزيف المعدة، أمراض الكلى، وبعض حالات القلب والحمل.","ألم أو حموضة المعدة، غثيان، احتباس سوائل، وقد يزيد خطر النزيف."),
  Drug("Aspirin","أسبرين / حمض أسيتيل الساليسيليك","Antiplatelet / Analgesic","يُستخدم حسب الوصفة في حالات معينة لتسكين الألم أو كمضاد صفائح.","يزيد خطر النزيف؛ لا يُعطى للأطفال/المراهقين لبعض الأمراض الفيروسية دون توجيه طبي.","تهيج المعدة، نزيف، حساسية أو تشنج قصبي لدى بعض الأشخاص."),
  Drug("Amoxicillin","أموكسيسيلين","Antibiotic\nمضاد حيوي","علاج بعض العدوى البكتيرية الحساسة له.","لا يفيد في العدوى الفيروسية؛ تحقق من حساسية البنسلين والتداخلات والوصفة.","إسهال، غثيان، طفح، وتفاعلات تحسسية قد تكون خطيرة."),
  Drug("Ceftriaxone","سيفترياكسون","Cephalosporin\nسيفالوسبورين","علاج عدوى بكتيرية معينة حسب التشخيص والبروتوكول.","تحقق من الحساسية والتوافق وطريقة الإعطاء؛ يستخدم بوصفة وتحت إشراف.","إسهال، ألم موضع الحقن، طفح أو حساسية."),
  Drug("Metronidazole","ميترونيدازول","Antimicrobial\nمضاد ميكروبي","يُستخدم ضد بعض العدوى البكتيرية والطفيلية.","تجنب الكحول أثناء العلاج ولفترة مناسبة حسب النشرة/التوجيه الطبي؛ راجع التداخلات.","غثيان، طعم معدني، إسهال، صداع."),
  Drug("Ondansetron","أوندانسيترون","Antiemetic\nمضاد قيء","الوقاية أو علاج الغثيان والقيء في حالات محددة.","الحذر مع اضطرابات نظم القلب وبعض الأدوية التي تطيل QT.","صداع، إمساك، وقد يحدث اضطراب نظم نادرًا."),
  Drug("Omeprazole","أوميبرازول","PPI\nمثبط مضخة البروتون","تقليل حمض المعدة في حالات مثل الارتجاع والقرحة.","راجع الاستخدام طويل المدى والتداخلات والحالات التي تحتاج تقييمًا طبيًا.","صداع، ألم بطني، إسهال أو إمساك."),
  Drug("Furosemide","فوروسيميد","Loop Diuretic\nمدر بول","تقليل احتباس السوائل في حالات معينة وعلاج بعض حالات ارتفاع الضغط.","يحتاج متابعة الضغط، السوائل، وظائف الكلى والأملاح.","جفاف، انخفاض ضغط، واضطراب الصوديوم أو البوتاسيوم."),
  Drug("Enoxaparin","إنوكسابارين","Anticoagulant\nمضاد تخثر","الوقاية أو العلاج من الجلطات حسب الحالة والوصفة.","خطر النزيف؛ راجع وظائف الكلى والأدوية الأخرى وإجراءات التخدير/الإبر حسب البروتوكول.","كدمات أو نزيف، أنيميا، وتفاعلات موضعية."),
  Drug("Heparin","هيبارين","Anticoagulant\nمضاد تخثر","الوقاية أو العلاج من الجلطات حسب الوصفة.","خطر النزيف وHIT؛ يحتاج متابعة مخبرية حسب نوع الاستخدام والبروتوكول.","نزيف، كدمات، ونادرًا نقص صفائح مناعي."),
  Drug("Insulin Regular","إنسولين Regular","Antidiabetic\nخافض سكر","خفض سكر الدم في حالات محددة حسب الخطة العلاجية.","أهم خطر هو نقص سكر الدم؛ تحقق من التركيز والوحدة والطريق والوجبة والبروتوكول قبل الإعطاء.","نقص سكر، زيادة وزن، وتفاعلات موضعية."),
  Drug("Salbutamol / Albuterol","سالبوتامول / ألبوتيرول","Bronchodilator\nموسع شعب","تخفيف تشنج الشعب الهوائية في حالات مثل الربو وCOPD.","استخدم حسب الخطة؛ الحذر مع بعض أمراض القلب واضطرابات النظم.","رعشة، خفقان، صداع."),
  Drug("Dexamethasone","ديكساميثازون","Corticosteroid\nكورتيكوستيرويد","تقليل الالتهاب أو التورم في حالات محددة حسب التشخيص.","قد يرفع السكر ويزيد خطر العدوى؛ لا يوقف العلاج طويل المدى فجأة دون توجيه.","ارتفاع السكر، أرق، تغيرات مزاجية، وزيادة خطر العدوى."),
  Drug("Hydrocortisone","هيدروكورتيزون","Corticosteroid\nكورتيكوستيرويد","يُستخدم في حالات التهابية أو نقص الكورتيزول حسب التشخيص.","الحذر من العدوى وارتفاع السكر؛ الاستخدام والجرعة حسب الحالة والبروتوكول.","ارتفاع السكر، احتباس سوائل، اضطراب مزاجي."),
  Drug("Morphine","مورفين","Opioid Analgesic\nمسكن أفيوني","تسكين الألم الشديد تحت إشراف طبي.","خطر تثبيط التنفس، انخفاض الوعي، والإدمان؛ يحتاج مراقبة دقيقة.","نعاس، غثيان، إمساك، وتثبيط التنفس."),
  Drug("Tramadol","ترامادول","Opioid Analgesic\nمسكن أفيوني","علاج بعض أنواع الألم عندما يكون مناسبًا وبوصفة.","خطر النعاس، التشنجات ومتلازمة السيروتونين مع بعض الأدوية؛ راجع التداخلات.","دوخة، غثيان، نعاس، إمساك."),
  Drug("Diazepam","ديازيبام","Benzodiazepine\nبنزوديازيبين","يُستخدم في حالات محددة مثل بعض التشنجات أو القلق أو التشنج العضلي.","قد يسبب تثبيط التنفس والاعتماد؛ خطر أعلى مع الأفيونات والكحول.","نعاس، دوخة، ضعف التنسيق."),
  Drug("Adrenaline / Epinephrine","أدرينالين / إبينفرين","Emergency\nطوارئ","دواء أساسي في حالات طارئة محددة مثل التأق، ويستخدم حسب البروتوكول.","دواء عالي الخطورة؛ الطريق والتركيز مهمان جدًا، واتبع بروتوكول الطوارئ.","خفقان، رعشة، قلق، صداع."),
  Drug("Nitroglycerin","نيتروغليسرين","Nitrate\nنترات","تخفيف ألم الذبحة في سياقات محددة حسب الوصفة.","قد يسبب انخفاض ضغط شديد؛ لا يُجمع مع بعض أدوية ضعف الانتصاب.","صداع، دوخة، انخفاض ضغط."),
  Drug("Amlodipine","أملوديبين","Calcium Channel Blocker","علاج ارتفاع الضغط وبعض حالات الذبحة.","راقب الضغط والوذمة؛ الاستخدام حسب الوصفة.","تورم القدمين، دوخة، احمرار."),
  Drug("Metoprolol","ميتوبرولول","Beta Blocker\nحاصر بيتا","ارتفاع الضغط وبعض أمراض القلب واضطرابات النظم حسب الحالة.","قد يبطئ النبض ويخفض الضغط؛ الحذر في بعض حالات الربو والسكري.","بطء النبض، دوخة، تعب."),
  Drug("Atorvastatin","أتورفاستاتين","Statin\nستاتين","خفض الكوليسترول وتقليل خطر أمراض القلب حسب الخطة العلاجية.","الحذر مع أمراض الكبد وبعض التداخلات؛ أبلغ عن ألم عضلي شديد.","ألم عضلي، اضطراب هضمي، ارتفاع إنزيمات الكبد."),
  Drug("Warfarin","وارفارين","Anticoagulant\nمضاد تخثر","الوقاية أو العلاج من الجلطات في حالات محددة.","تداخلات دوائية وغذائية كثيرة؛ يحتاج متابعة INR ولا يُستخدم دون وصفة.","نزيف، كدمات."),
  Drug("Loratadine","لوراتادين","Antihistamine\nمضاد حساسية","أعراض الحساسية والرشح التحسسي.","راجع أمراض الكبد والتداخلات حسب المنتج.","صداع، جفاف الفم، نعاس أقل من بعض مضادات الحساسية القديمة."),
  Drug("Cetirizine","سيتريزين","Antihistamine\nمضاد حساسية","أعراض الحساسية والشرى.","قد يسبب نعاسًا؛ الحذر مع المهدئات وبعض حالات الكلى.","نعاس، جفاف الفم، تعب."),
  Drug("Ferrous Sulfate","كبريتات الحديد","Iron Supplement\nمكمل حديد","علاج أو وقاية من نقص الحديد عند وصفه.","يُستخدم عند وجود حاجة؛ قد تتداخل امتصاصاته مع بعض الأدوية والطعام.","إمساك، غثيان، براز داكن."),
  Drug("Potassium Chloride","كلوريد البوتاسيوم","Electrolyte\nإلكتروليت","تصحيح نقص البوتاسيوم عندما يكون موصوفًا.","دواء عالي الخطورة؛ التركيز والطريق ومعدل الإعطاء مهمون جدًا ويجب اتباع بروتوكول المنشأة.","غثيان، ألم موضعي، واضطراب نظم خطير عند ارتفاع البوتاسيوم."),
  Drug("Normal Saline 0.9%","محلول ملحي 0.9%","IV Fluid\nمحلول وريدي","تعويض سوائل أو كحامل/مذيب في استخدامات محددة حسب الحالة.","راقب حالة السوائل والصوديوم خاصة في مرضى القلب والكلى.","احتباس سوائل أو اضطراب أملاح عند الإفراط."),
  Drug("Dextrose 5%","جلوكوز 5% / ديكستروز","IV Fluid\nمحلول وريدي","مصدر ماء وجلوكوز في استخدامات محددة حسب الحالة.","قد يرفع سكر الدم ويؤثر على توازن السوائل؛ حسب الحالة والبروتوكول.","ارتفاع سكر أو اضطراب سوائل/أملاح.")
 )

 private fun medicines(){page="medicines";parentPage="home";
  clear("💊 دليل الأدوية","Drug Guide • عربي أولًا • معلومات تعليمية وليست وصفة")
  val search=inp("ابحث باسم الدواء أو الاسم الإنجليزي… / Search")
  add(search)
  val cat=Spinner(this)
  val cats=arrayOf("كل الأدوية • All","Pain & Fever","Antibiotics","Emergency","Cardio","Anticoagulants","GI","Respiratory","Endocrine","CNS","Fluids & Electrolytes","Other")
  cat.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats)
  body.addView(cat,LinearLayout.LayoutParams(-1,dp(52)).apply{bottomMargin=dp(10)})
  val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  body.addView(list)
  fun refresh(){
   list.removeAllViews()
   val q=search.text.toString().trim().lowercase()
   val chosen=cat.selectedItem?.toString()?:"كل الأدوية • All"
   drugs.filter{
    val text=(it.generic+" "+it.ar+" "+it.category+" "+it.uses).lowercase()
    val categoryOk=chosen.startsWith("كل") || it.category.contains(chosen.split("\n")[0],true) ||
      (chosen=="Pain & Fever" && it.category.contains("Pain",true)) ||
      (chosen=="Antibiotics" && it.category.contains("Antibiotic",true)) ||
      (chosen=="Emergency" && it.category.contains("Emergency",true)) ||
      (chosen=="Cardio" && (it.category.contains("Cardio",true)||it.generic.contains("Amlodipine")||it.generic.contains("Metoprolol")||it.generic.contains("Nitroglycerin")||it.generic.contains("Atorvastatin"))) ||
      (chosen=="Anticoagulants" && it.category.contains("Anticoagulant",true)) ||
      (chosen=="GI" && it.category.contains("PPI",true)) ||
      (chosen=="Respiratory" && it.category.contains("Bronchodilator",true)) ||
      (chosen=="Endocrine" && (it.category.contains("Antidiabetic",true)||it.generic.contains("Hydrocortisone"))) ||
      (chosen=="CNS" && (it.category.contains("Opioid",true)||it.category.contains("Benzodiazepine",true))) ||
      (chosen=="Fluids & Electrolytes" && it.category.contains("IV Fluid",true))
    categoryOk && (q.isEmpty() || text.contains(q))
   }.forEach{d->
    val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(14),dp(15),dp(14));background=glass();setOnClickListener{drugDetail(d)}}
    c.addView(tv(d.ar,18f,fg(),true))
    c.addView(tv(d.generic,13f,accent,true))
    c.addView(tv(d.category,11f,muted()))
    c.addView(tv("اضغط للشرح الكامل • Tap for details",10f,muted()))
    list.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(9)})
   }
   if(list.childCount==0) list.addView(tv("لا توجد نتيجة.\nNo matching medicine.",14f,muted()).apply{setPadding(dp(12),dp(20),dp(12),dp(20))})
  }
  search.addTextChangedListener(object:android.text.TextWatcher{
   override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
   override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){refresh()}
   override fun afterTextChanged(e:android.text.Editable?){}
  })
  cat.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
   override fun onNothingSelected(p:AdapterView<*>?){}
   override fun onItemSelected(p:AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){refresh()}
  }
  refresh()
 }

 private fun drugDetail(d:Drug){page="drugDetail";parentPage="medicines";
  clear("💊 ${d.ar}","${d.generic} • ${d.category}")
  fun section(title:String,text:String){
   val c=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=glass()}
   c.addView(tv(title,14f,accent,true));c.addView(tv(text,14f,fg()))
   body.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
  }
  section("دواعي الاستعمال • Uses",d.uses)
  section("التحذيرات • Warnings",d.warnings)
  section("الآثار الجانبية الشائعة • Common side effects",d.effects)
  section("ملاحظة تمريضية • Nursing note","تحقق من اسم الدواء، المادة الفعالة، التركيز، الطريق، الحساسية، التداخلات، ووصفة الطبيب/بروتوكول المنشأة قبل الإعطاء. هذه البطاقة لا تعرض جرعة علاجية.")
  section("مصدر المعلومات • Source","تم تصميم قسم الأدوية ليكون مرجعًا تعليميًا مختصرًا، ويجب الرجوع للنشرة الرسمية ومصادر الأدوية الموثوقة للحصول على أحدث التفاصيل.")
 }
 private fun contact(){
  page="contact"; parentPage="home"
  clear("📲 تواصل مع Hakamo","Official links • روابط التواصل الرسمية")
  fun link(label:String,url:String){
    val c=LinearLayout(this).apply{
      orientation=LinearLayout.HORIZONTAL
      gravity=Gravity.CENTER_VERTICAL
      setPadding(dp(15),dp(12),dp(15),dp(12))
      background=glass()
      setOnClickListener{
        try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){toast("تعذر فتح الرابط")}
      }
    }
    c.addView(tv(label,15f,fg(),true),LinearLayout.LayoutParams(0,-2,1f))
    c.addView(tv("›",28f,accent))
    body.addView(c,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(10)})
  }
  link("📢 Telegram • قناة Hakamo","https://t.me/Hakamo99")
  link("🎵 TikTok • @hakamo99","https://www.tiktok.com/@hakamo99?_r=1&_t=ZS-91x1jX1y20z")
  link("📘 Facebook • Hakamo","https://www.facebook.com/share/19QwF7nvvf/")
  link("▶️ YouTube • @hakamo99","https://youtube.com/@hakamo99")
  link("📚 كل اللي هتحتاجه في القناة","https://t.me/Hakamo99/1978")
  body.addView(tv("للتواصل والاستفسارات تابع روابط Hakamo الرسمية بالأعلى.\nFor contact and updates, use the official Hakamo links above.",12f,muted()).apply{setPadding(dp(4),dp(10),dp(4),dp(10))})
 }
 private fun reference(){page="reference";parentPage="home";clear("📚 Reference","معلومات سريعة — لا تغني عن مرجع المنشأة");menu("❤️","Vital Signs\nالعلامات الحيوية","النطاقات تعتمد على العمر والسياق"){info("Vital Signs\nالعلامات الحيوية","استخدم مرجع المستشفى/الفئة العمرية عند تفسير العلامات الحيوية.")};menu("🧪","Lab Values\nقيم التحاليل","CBC • Electrolytes • Renal • Glucose\nصورة الدم • الأملاح • الكلى • السكر"){info("Lab Values\nقيم التحاليل","النطاق المرجعي في تقرير المختبر هو المرجع الأساسي.")};menu("🔤","Abbreviations\nالاختصارات","PRN • STAT • NPO • I&O • IV"){info("Abbreviations\nالاختصارات","PRN عند الحاجة • STAT فورًا • NPO ممنوع فمويًا • I&O الداخل والخارج • IV وريدي")};menu("🧤","Safety\nالسلامة","Medication • Injection • Sharps • IV"){info("Safety\nالسلامة","اتبع سياسة المنشأة وممارسات مكافحة العدوى وسلامة الدواء.")}}
 private fun info(a:String,b:String){page="info";parentPage="reference";clear(a,"مرجع سريع");val c=tv(b,15f);c.setPadding(dp(16),dp(18),dp(16),dp(18));c.background=glass();body.addView(c)}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()

}
