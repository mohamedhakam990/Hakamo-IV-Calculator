# Hakamo Nursing Assistant • Windows

نسخة Windows مكتبية من Hakamo Nursing Assistant باستخدام Kotlin + Compose Multiplatform.

## البناء

- Java 17
- Kotlin 2.2.20
- Compose Multiplatform 1.12.0
- Windows 10/11 x64

الأمر:
`gradle packageReleaseExe packageReleaseMsi`

الناتج يكون EXE وMSI داخل `build/compose/binaries/`.
