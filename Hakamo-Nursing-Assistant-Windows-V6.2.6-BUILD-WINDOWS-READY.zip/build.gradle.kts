plugins {
    kotlin("jvm") version "2.2.20" apply false
    id("org.jetbrains.compose") version "1.12.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.20" apply false
}
plugins {
    kotlin("jvm")
    id("org.jetbrains.compose")
    id("org.jetbrains.kotlin.plugin.compose")
}

dependencies { implementation(compose.desktop.currentOs) }

compose.desktop {
    application {
        mainClass = "com.hakamo.nursing.MainKt"
        nativeDistributions {
            targetFormats(org.jetbrains.compose.desktop.application.dsl.TargetFormat.Exe,
                          org.jetbrains.compose.desktop.application.dsl.TargetFormat.Msi)
            packageName = "Hakamo Nursing Assistant"
            packageVersion = "6.2.6"
            description = "Hakamo Nursing Assistant - مساعد التمريض"
            vendor = "Hakamo"
            windows {
                menuGroup = "Hakamo"
                perUserInstall = true
                dirChooser = true
                console = false
            }
        }
    }
}
