package com.hakamo.nursing

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import androidx.compose.ui.window.WindowPosition
import androidx.compose.ui.unit.IntSize

private data class Section(val icon:String, val title:String, val subtitle:String)
private data class Procedure(val title:String, val goal:String, val steps:List<String>, val safety:List<String>)

private val sections = listOf(
    Section("💊", "دليل الأدوية", "بحث ومعلومات مرجعية عن الأدوية"),
    Section("🧰", "إجراءات التمريض", "شرح عربي خطوة بخطوة"),
    Section("🧮", "حاسبات التمريض", "محاليل • جرعات • BMI • تحويلات"),
    Section("🩺", "تقييم المريض", "العلامات الحيوية • GCS • NEWS2"),
    Section("🧪", "التحاليل", "القيم المرجعية وشرح الاختصارات"),
    Section("🚨", "الطوارئ", "مرجع سريع للتعامل الأولي"),
    Section("❤️", "العناية الحرجة", "مراقبة المريض والعناية المركزة"),
    Section("🩹", "الجروح والغيارات", "تقييم الجروح والعناية بها"),
    Section("👶", "الأطفال", "مرجع تمريضي للأطفال"),
    Section("🤰", "النساء والتوليد", "مرجع تمريضي للنساء والتوليد"),
    Section("🩸", "نقل الدم", "السلامة والمراقبة أثناء النقل"),
    Section("🦠", "مكافحة العدوى", "نظافة اليدين ومعدات الوقاية"),
    Section("📚", "المرجع التمريضي", "مفاهيم واختصارات تمريضية"),
    Section("📋", "التوثيق و SBAR", "تسليم واستلام وتوثيق الحالة")
)

private val procedures = listOf(
    Procedure("قياس العلامات الحيوية", "متابعة حالة المريض واكتشاف التغيرات مبكرًا", listOf("تحقق من هوية المريض واشرح الإجراء.", "اجعل المريض في وضع مناسب وخذ الحرارة والنبض والتنفس وضغط الدم وSpO₂ حسب الأدوات المتاحة.", "سجل القراءة مع الوقت والوضعية والطريقة عند الحاجة.", "قارن بالقراءات السابقة وأبلغ عن التغيرات غير الطبيعية وفق سياسة المكان."), listOf("استخدم جهازًا سليمًا ومقاس كفة ضغط مناسب.", "لا تعتمد على رقم منفرد دون النظر إلى حالة المريض.")),
    Procedure("غسل اليدين", "تقليل انتقال العدوى", listOf("أزل الحلي قدر الإمكان وبلل اليدين.", "ضع الصابون وافرك راحة اليدين وظهورهما وبين الأصابع وحول الإبهام والأظافر.", "اشطف جيدًا وجفف بمنشفة نظيفة.", "استخدم مطهر اليدين الكحولي عندما يكون مناسبًا وفق سياسة مكافحة العدوى."), listOf("التزم بلحظات نظافة اليدين المعتمدة في المنشأة.", "لا تلمس الأسطح الملوثة بعد الانتهاء.")),
    Procedure("ارتداء وخلع معدات الوقاية الشخصية", "حماية المريض ومقدم الرعاية من التعرض للعدوى", listOf("اختر معدات الوقاية المناسبة لنوع التعرض المتوقع.", "ارتدِ المعدات بالترتيب المعتمد محليًا وتأكد من تغطية مناطق التعرض.", "عند الخلع تجنب لمس الأسطح الملوثة وتخلص من المعدات بالطريقة الصحيحة.", "نفذ نظافة اليدين في الأوقات المناسبة."), listOf("اتبع سياسة مكافحة العدوى المحلية ونوع الاحتياطات المطلوبة.")),
    Procedure("تركيب الكانيولا الوريدية", "توفير مدخل وريدي للعلاج والسوائل", listOf("تحقق من أمر العلاج وهوية المريض والحساسية.", "اختر الوريد والمقاس المناسبين حسب العلاج وحالة المريض.", "نظف الجلد بمطهر مناسب واتركه يجف.", "أدخل القسطرة وفق التدريب العملي وسياسة المنشأة، ثم ثبتها وافحص سلامتها.", "تخلص من الإبرة فورًا في حاوية الأدوات الحادة وسجل الإجراء."), listOf("استخدم تقنية معقمة.", "راقب الألم والاحمرار والتورم والتسرب وعلامات العدوى.")),
    Procedure("إعطاء الحقن العضلي", "إعطاء دواء عبر النسيج العضلي", listOf("تحقق من الدواء والجرعة والطريق وهوية المريض والحساسية.", "اختر موقع الحقن المناسب حسب العمر والدواء وسياسة المنشأة.", "نفذ التعقيم والتقنية المناسبة وفق تدريبك العملي.", "تخلص من الإبرة مباشرة وسجل الدواء ووقت إعطائه."), listOf("لا تستخدم موقعًا به التهاب أو إصابة.", "اتبع سياسة المنشأة بخصوص الحد الأقصى للحجم والمواقع.")),
    Procedure("إعطاء حقن تحت الجلد", "إعطاء الدواء في النسيج تحت الجلد", listOf("تحقق من الدواء والجرعة والطريق وهوية المريض.", "اختر الموقع المناسب وافحص الجلد.", "استخدم التقنية والزاوية المناسبة حسب نوع الدواء وتعليمات المنشأة.", "تخلص من الإبرة بأمان وسجل الإعطاء."), listOf("الأدوية المختلفة لها تعليمات مختلفة؛ لا تفترض أن التقنية واحدة لكل دواء.")),
    Procedure("تركيب القسطرة البولية", "تصريف البول ومراقبة الإخراج عند وجود داعٍ سريري", listOf("تحقق من وجود داعٍ للقسطرة واشرح الإجراء واحفظ الخصوصية.", "جهز الأدوات المعقمة ونفذ نظافة اليدين.", "استخدم تقنية معقمة واتبع تعليمات القسطرة وسياسة المنشأة.", "ثبت القسطرة بطريقة مناسبة وحافظ على نظام التصريف المغلق.", "سجل الإجراء وراقب البول ومكان الإدخال."), listOf("تجنب القسطرة غير الضرورية.", "راقب علامات العدوى والألم والانسداد.")),
    Procedure("تركيب أنبوب أنفي معدي", "إدخال أنبوب للمعدة لأغراض محددة مثل التغذية أو التفريغ", listOf("تحقق من الأمر الطبي وهوية المريض وموانع الإجراء.", "اشرح الإجراء وضع المريض في الوضع المناسب.", "أدخل الأنبوب تدريجيًا وفق التدريب والبروتوكول.", "تأكد من موضع الأنبوب بالطريقة المعتمدة محليًا قبل استخدامه.", "ثبت الأنبوب وسجل المقاس والموضع والاستجابة."), listOf("لا تبدأ التغذية أو إعطاء الدواء قبل تأكيد الموضع بالطريقة المطلوبة.")),
    Procedure("إعطاء الأكسجين", "تحسين الأكسجة عند وجود حاجة سريرية", listOf("قيّم التنفس وSpO₂ وحالة المريض.", "اختر وسيلة الأكسجين ومعدل التدفق حسب الأمر أو البروتوكول.", "ثبت الوسيلة وتأكد من راحة المريض.", "أعد تقييم الاستجابة وسجل الوسيلة والتدفق والقراءات."), listOf("الأكسجين علاج طبي؛ اتبع الهدف المحدد للمريض والبروتوكول.", "أبعد مصادر الاشتعال عن الأكسجين.")),
    Procedure("شفط الإفرازات", "إزالة الإفرازات عندما تعيق مجرى الهواء أو التهوية", listOf("قيّم الحاجة وحالة التنفس قبل الإجراء.", "جهز معدات الشفط ووسائل الحماية.", "نفذ الإجراء بالتقنية المناسبة للمسار المستخدم ووفق البروتوكول.", "راقب SpO₂ والنبض والاستجابة وأوقف الإجراء عند ظهور تدهور.", "سجل كمية وطبيعة الإفرازات واستجابة المريض."), listOf("لا تكرر الشفط بلا حاجة.", "التزم بضغط الشفط ومدة الإجراء المحددين في سياسة المنشأة.")),
    Procedure("تغيير الغيار على الجرح", "حماية الجرح ومتابعة الالتئام وتقليل خطر العدوى", listOf("تحقق من هوية المريض واشرح الإجراء.", "جهز الأدوات المناسبة ونظف اليدين وارتدِ معدات الوقاية المطلوبة.", "أزل الغيار القديم بحذر وقيّم الجرح.", "نظف وغطِّ الجرح وفق نوعه والخطة العلاجية.", "تخلص من النفايات وسجل وصف الجرح والإجراء."), listOf("استخدم تقنية نظيفة أو معقمة حسب نوع الجرح والبروتوكول.", "أبلغ عن النزيف أو التدهور أو علامات العدوى.")),
    Procedure("قياس سكر الدم بجهاز القياس", "الحصول على قراءة سكر الدم ومتابعتها", listOf("تحقق من هوية المريض والطلب.", "نظف اليدين وارتدِ القفازات عند الحاجة.", "استخدم شريطًا صالحًا وجهازًا معايرًا حسب تعليماته.", "خذ العينة بالطريقة الصحيحة وسجل القراءة والوقت.", "تصرف وفق بروتوكول انخفاض أو ارتفاع السكر عند وجود قراءة غير طبيعية."), listOf("لا تشارك أدوات الوخز بين المرضى.", "تخلص من أداة الوخز في حاوية الأدوات الحادة.")),
    Procedure("جمع عينة بول", "الحصول على عينة مناسبة للفحص", listOf("اشرح للمريض طريقة جمع العينة ونظافة المنطقة حسب التعليمات.", "استخدم الوعاء المخصص ولا تلمس داخله.", "اجمع العينة بالطريقة المطلوبة للفحص المحدد.", "أغلق الوعاء واكتب البيانات وأرسلها وفق سياسة المختبر."), listOf("استخدم عينة معقمة عندما يطلب ذلك.", "تجنب تأخير إرسال العينة.")),
    Procedure("نقل الدم ومراقبته", "إعطاء مكونات الدم بأمان مع اكتشاف التفاعلات مبكرًا", listOf("تحقق من أمر النقل وهوية المريض والمكون وبيانات التوافق وفق سياسة المنشأة.", "سجل العلامات الحيوية الأساسية وابدأ المراقبة حسب البروتوكول.", "راقب المريض عن قرب خصوصًا في بداية النقل.", "عند الاشتباه في تفاعل أوقف النقل واتبع بروتوكول المنشأة واطلب المساعدة فورًا.", "وثق المكون والوقت والجرعات والعلامات الحيوية والاستجابة."), listOf("لا تبدأ نقل الدم قبل اكتمال فحوص الهوية والتوافق المطلوبة.", "التعامل مع تفاعل نقل الدم إجراء طارئ ويتبع سياسة المنشأة.")),
    Procedure("التعامل مع إصابة وخز الإبرة", "تقليل خطر العدوى والتعرض المهني", listOf("اغسل موضع الإصابة بالماء والصابون دون عصر الجرح بعنف.", "أبلغ المسؤول المختص فورًا حسب نظام المنشأة.", "وثق الواقعة واتبع تقييم التعرض المهني والفحوصات الوقائية المعتمدة.", "التزم بمتابعة الصحة المهنية وفق البروتوكول."), listOf("لا تتأخر في الإبلاغ بعد التعرض.", "لا تعِد استخدام الأدوات الحادة أو تعيد تغطية الإبر.")),
    Procedure("نقل المريض من السرير إلى الكرسي", "نقل المريض بأمان وتقليل خطر السقوط والإصابة", listOf("قيّم قدرة المريض على الحركة وخطر السقوط.", "اشرح الخطوات وتأكد من ثبات السرير والكرسي.", "استخدم وسيلة المساعدة المناسبة واطلب مساعدة إضافية عند الحاجة.", "انقل المريض تدريجيًا مع مراقبة الدوخة أو عدم الاتزان.", "تأكد من وضع المريض بأمان بعد النقل."), listOf("لا تنفذ النقل منفردًا إذا كانت حالة المريض تتطلب شخصين أو جهاز رفع.", "استخدم ميكانيكا الجسم الصحيحة."))
)

fun main() = application {
    val state = rememberWindowState(width = 1200.dp, height = 760.dp, position = WindowPosition(Alignment.Center))
    Window(onCloseRequest = ::exitApplication, title = "Hakamo Nursing Assistant • مساعد التمريض", state = state) {
        App()
    }
}

@Composable
private fun App() {
    var page by remember { mutableStateOf("home") }
    var selectedProcedure by remember { mutableStateOf<Procedure?>(null) }
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF101418)) {
            Row(Modifier.fillMaxSize()) {
                Sidebar(page) { page = it; selectedProcedure = null }
                Box(Modifier.fillMaxSize().padding(22.dp)) {
                    when {
                        selectedProcedure != null -> ProcedureDetails(selectedProcedure!!) { selectedProcedure = null }
                        page == "procedures" -> ProceduresPage { selectedProcedure = it }
                        else -> HomePage(page) { page = it }
                    }
                }
            }
        }
    }
}

@Composable private fun Sidebar(page:String, onPage:(String)->Unit) {
    Column(Modifier.width(260.dp).fillMaxHeight().background(Color(0xFF171D22)).padding(18.dp)) {
        Text("HAKAMO", color=Color(0xFF58C7D9), fontSize=27.sp, fontWeight=FontWeight.Bold)
        Text("مساعد التمريض", color=Color.LightGray, fontSize=15.sp)
        Spacer(Modifier.height(24.dp))
        listOf("home" to "🏠  الرئيسية", "procedures" to "🧰  إجراءات التمريض", "drugs" to "💊  دليل الأدوية", "calculators" to "🧮  الحاسبات", "reference" to "📚  المرجع التمريضي").forEach { (id,label) ->
            Surface(color = if(page==id) Color(0xFF223A40) else Color.Transparent, modifier=Modifier.fillMaxWidth().padding(vertical=3.dp)) {
                Text(label, color=Color.White, modifier=Modifier.fillMaxWidth().clickable{onPage(id)}.padding(13.dp), fontSize=16.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        Text("نسخة Windows  •  V6.2.6", color=Color.Gray, fontSize=12.sp)
    }
}

@Composable private fun HomePage(page:String, go:(String)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(if(page=="home") "مساعد التمريض Hakamo" else "قسم ${sections.firstOrNull{it.title.contains(if(page=="drugs")"الأدوية" else if(page=="calculators")"حاسبات" else "المرجع") }?.title ?: "المرجع")}", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Bold)
        Text("مرجع تمريضي عربي للاستخدام التعليمي والمراجعة", color=Color.Gray, fontSize=15.sp)
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(if(page=="home") sections else sections.filter{ true }) { s ->
                Card(Modifier.fillMaxWidth().clickable{ if(s.title=="إجراءات التمريض") go("procedures") }, backgroundColor=Color(0xFF1A2228), elevation=3.dp) {
                    Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(s.icon, fontSize=30.sp); Spacer(Modifier.width(16.dp)); Column { Text(s.title,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold); Text(s.subtitle,color=Color.Gray) }
                    }
                }
            }
        }
    }
}

@Composable private fun ProceduresPage(onOpen:(Procedure)->Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("إجراءات التمريض", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Bold)
        Text("شرح عربي تعليمي — اتبع تدريبك العملي وسياسة المنشأة في التنفيذ", color=Color(0xFFB9C5CA), fontSize=14.sp)
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(procedures) { p -> Card(Modifier.fillMaxWidth().clickable{onOpen(p)}, backgroundColor=Color(0xFF1A2228)) { Column(Modifier.padding(16.dp)) { Text(p.title,color=Color.White,fontSize=19.sp,fontWeight=FontWeight.Bold); Text(p.goal,color=Color.Gray); Spacer(Modifier.height(8.dp)); Text("فتح الشرح ←",color=Color(0xFF58C7D9)) } } }
        }
    }
}

@Composable private fun ProcedureDetails(p:Procedure, back:()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("‹ رجوع", color=Color(0xFF58C7D9), modifier=Modifier.clickable{back()}.padding(4.dp))
        Spacer(Modifier.height(8.dp)); Text(p.title,color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Bold); Text(p.goal,color=Color.Gray,fontSize=15.sp)
        Spacer(Modifier.height(18.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)) {
            item { Card(backgroundColor=Color(0xFF1A2228)) { Column(Modifier.padding(18.dp)) { Text("الخطوات التعليمية",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp)); p.steps.forEachIndexed{ i,s -> Text("${i+1}. $s",color=Color(0xFFE5E9EB),modifier=Modifier.padding(vertical=5.dp),fontSize=15.sp) } } } }
            item { Card(backgroundColor=Color(0xFF202A2F)) { Column(Modifier.padding(18.dp)) { Text("نقاط السلامة",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp)); p.safety.forEach{s -> Text("• $s",color=Color(0xFFE5E9EB),modifier=Modifier.padding(vertical=5.dp),fontSize=15.sp)} } } }
            item { Text("ملاحظة: هذا المحتوى تعليمي ومرجعي ولا يغني عن التدريب العملي أو بروتوكولات وسياسات المنشأة أو توجيه الفريق المعالج.",color=Color(0xFFFFC857),fontSize=13.sp,modifier=Modifier.padding(vertical=10.dp)) }
        }
    }
}
